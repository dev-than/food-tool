const TIME_OPTS = [
  { id: 'any', label: 'Any time' },
  { id: 'u30', label: 'Under 30' },
  { id: '30-60', label: '30–60' },
  { id: 'o60', label: 'Over 60' },
];

const MADE_OPTS = [
  { id: 'any', label: 'All' },
  { id: 'unscheduled', label: 'No date' },
  { id: 'recent', label: 'Last 14 days' },
  { id: 'stale', label: '30+ days ago' },
];

const SORT_OPTS = [
  { id: 'name', label: 'Name (A–Z)' },
  { id: 'recent', label: 'Most recent date' },
  { id: 'oldest', label: 'Oldest date' },
  { id: 'quick', label: 'Quickest to cook' },
];

function Group({ label, options, value, onChange }) {
  return (
    <div className="filter-group">
      <span className="filter-label">{label}</span>
      <div className="chips">
        {options.map((o) => (
          <button
            key={o.id}
            className={'chip' + (value === o.id ? ' chip-on' : '')}
            onClick={() => onChange(o.id)}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function Filters({ filters, onChange }) {
  const set = (key) => (val) => onChange({ ...filters, [key]: val });

  return (
    <div className="filters">
      <Group
        label="Cook time"
        options={TIME_OPTS}
        value={filters.time}
        onChange={set('time')}
      />
      <Group
        label="Scheduled"
        options={MADE_OPTS}
        value={filters.made}
        onChange={set('made')}
      />
      <div className="filter-group">
        <span className="filter-label">Sort</span>
        <select
          className="sort-select"
          value={filters.sort}
          onChange={(e) => set('sort')(e.target.value)}
        >
          {SORT_OPTS.map((o) => (
            <option key={o.id} value={o.id}>
              {o.label}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}

export const DEFAULT_FILTERS = { time: 'any', made: 'any', sort: 'name' };
