import { useState, useRef, useEffect } from 'react';
import { K } from '../lib/recipe.js';
import { dateRange, todayIso, parts, daysFromToday } from '../lib/dates.js';

const DAYS = 14;

export default function Timeline({
  recipes,
  onAssign,
  onOpen,
  dragging,
}) {
  const days = dateRange(todayIso(), DAYS);
  const [overDay, setOverDay] = useState(null);
  const [searchDay, setSearchDay] = useState(null);

  const byDay = {};
  for (const r of recipes) {
    const d = r[K.date];
    if (d) (byDay[d] ||= []).push(r);
  }

  const handleDrop = (e, day) => {
    e.preventDefault();
    setOverDay(null);
    const id = e.dataTransfer.getData('text/plain');
    if (id) onAssign(id, day);
  };

  return (
    <div className="timeline-wrap">
      <div className="timeline" role="list">
        {days.map((day) => {
          const list = byDay[day] || [];
          const delta = daysFromToday(day);
          const p = parts(day);
          const isToday = delta === 0;
          const isTomorrow = delta === 1;

          return (
            <div
              key={day}
              role="listitem"
              className={
                'day' +
                (isToday ? ' day-today' : '') +
                (overDay === day ? ' day-over' : '') +
                (dragging ? ' day-armed' : '')
              }
              onDragOver={(e) => {
                if (dragging) {
                  e.preventDefault();
                  setOverDay(day);
                }
              }}
              onDragLeave={() =>
                setOverDay((cur) => (cur === day ? null : cur))
              }
              onDrop={(e) => handleDrop(e, day)}
            >
              <button
                className="day-head"
                onClick={() => setSearchDay(searchDay === day ? null : day)}
                title="Add a recipe to this day"
              >
                <span className="day-wd">
                  {isToday ? 'Today' : isTomorrow ? 'Tmrw' : p.weekday}
                </span>
                <span className="day-num">{p.day}</span>
                <span className="day-mo">{p.month}</span>
              </button>

              <div className="day-body">
                {list.map((r) => (
                  <button
                    key={r[K.id]}
                    className="pill"
                    onClick={() => onOpen(r)}
                    title={r[K.name]}
                  >
                    {(r[K.night] || '').trim() && (
                      <span className="pill-dot" title="Has prep" />
                    )}
                    <span className="pill-name">
                      {r[K.name] || 'Untitled'}
                    </span>
                  </button>
                ))}
                {dragging && list.length === 0 && (
                  <span className="day-hint">drop here</span>
                )}
              </div>

              {searchDay === day && (
                <DaySearch
                  recipes={recipes}
                  onPick={(id) => {
                    onAssign(id, day);
                    setSearchDay(null);
                  }}
                  onClose={() => setSearchDay(null)}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DaySearch({ recipes, onPick, onClose }) {
  const [q, setQ] = useState('');
  const ref = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
    const onDoc = (e) => {
      if (ref.current && !ref.current.contains(e.target)) onClose();
    };
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [onClose]);

  const needle = q.trim().toLowerCase();
  const matches = recipes
    .filter((r) => (r[K.name] || '').toLowerCase().includes(needle))
    .slice(0, 8);

  return (
    <div className="day-search" ref={ref}>
      <input
        ref={inputRef}
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Find a recipe…"
      />
      <div className="day-search-list">
        {matches.length === 0 ? (
          <div className="day-search-empty">No matches</div>
        ) : (
          matches.map((r) => (
            <button
              key={r[K.id]}
              className="day-search-item"
              onClick={() => onPick(r[K.id])}
            >
              {r[K.name] || 'Untitled'}
            </button>
          ))
        )}
      </div>
    </div>
  );
}
