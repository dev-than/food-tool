import { useState, useEffect } from 'react';
import { K, emptyRecipe } from '../lib/recipe.js';

export default function Editor({ recipe, onSave, onDelete, onClose }) {
  const isNew = !recipe[K.id];
  const [form, setForm] = useState(recipe);
  const [saving, setSaving] = useState(false);

  useEffect(() => setForm(recipe), [recipe]);

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && !saving && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose, saving]);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const sourceUrl = (form[K.source] || '').trim();
  const sourceOk = /^https?:\/\//i.test(sourceUrl);

  const submit = async () => {
    if (!(form[K.name] || '').trim()) return;
    setSaving(true);
    try {
      await onSave(form);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="scrim" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sheet" role="dialog" aria-modal="true">
        <h2>{isNew ? 'Add recipe' : 'Edit recipe'}</h2>

        <div className="field">
          <label>Recipe name</label>
          <input
            value={form[K.name] || ''}
            onChange={set(K.name)}
            placeholder="Weeknight chana masala"
            autoFocus
          />
        </div>

        <div className="field">
          <label>
            Original recipe <span className="hint">— link to the source</span>
          </label>
          <input
            type="url"
            value={form[K.source] || ''}
            onChange={set(K.source)}
            placeholder="https://…"
          />
          {sourceOk && (
            <a
              className="source-link"
              href={sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
            >
              Open original ↗
            </a>
          )}
        </div>

        <div className="row2">
          <div className="field">
            <label>Scheduled for</label>
            <input type="date" value={form[K.date] || ''} onChange={set(K.date)} />
          </div>
          <div className="field">
            <label>Cook time (minutes)</label>
            <input
              type="number"
              min="0"
              value={form[K.time] || ''}
              onChange={set(K.time)}
              placeholder="45"
            />
          </div>
        </div>

        <div className="field">
          <label>
            Night before task{' '}
            <span className="hint">— leave empty if nothing to do</span>
          </label>
          <input
            value={form[K.night] || ''}
            onChange={set(K.night)}
            placeholder="Soak the beans"
          />
        </div>

        <div className="field">
          <label>Image URL</label>
          <input value={form[K.img] || ''} onChange={set(K.img)} placeholder="https://…" />
        </div>

        <div className="field">
          <label>
            Ingredients <span className="hint">— one per line</span>
          </label>
          <textarea value={form[K.ing] || ''} onChange={set(K.ing)} />
        </div>

        <div className="field">
          <label>
            Instructions <span className="hint">— one step per line</span>
          </label>
          <textarea value={form[K.ins] || ''} onChange={set(K.ins)} />
        </div>

        <div className="sheet-actions">
          <button className="btn btn-go" onClick={submit} disabled={saving}>
            {saving ? 'Saving…' : 'Save'}
          </button>
          <button className="btn-quiet" onClick={onClose} disabled={saving}>
            Cancel
          </button>
          <span className="spacer" />
          {!isNew && (
            <button
              className="btn-danger"
              onClick={() => onDelete(form)}
              disabled={saving}
            >
              Delete
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export { emptyRecipe };
